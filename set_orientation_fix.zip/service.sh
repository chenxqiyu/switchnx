#!/system/bin/sh
MODDIR=${0%/*}
i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 60 ]; do
    sleep 1
    i=$((i+1))
done
sleep 3
wm set-fix-to-user-rotation disabled
log -t set_orientation_fix "fixed-to-user-rotation disabled"
